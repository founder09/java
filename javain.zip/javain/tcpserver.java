import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.net.*;

public class tcpserver extends JFrame implements ActionListener{
JButton sd,et;
static JTextArea ms;
JScrollPane sb;
Container c;
static JTextField jtf;
static ServerSocket s1;
static Socket s;
public tcpserver()
{
jtf=new JTextField(15);

sd=new JButton("SEND");
et=new JButton("EXIT");
ms=new JTextArea();
sb=new JScrollPane(ms);
sb.setPreferredSize(new Dimension(300,100));

ms.setLineWrap(true);
ms.setWrapStyleWord(true);

ms.setEditable(false);
sb.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
c=getContentPane();
c.setLayout(new FlowLayout());
c.add(jtf);
c.add(sb);
c.add(sd);
c.add(et);
jtf.requestFocus();
sd.addActionListener(this);
et.addActionListener(this);
}

public void actionPerformed(ActionEvent ae)
{
if(ae.getActionCommand().equals("SEND"))
{
try{
String str1=jtf.getText();
ms.setText(ms.getText()+"\nMe: "+str1);
PrintWriter p=new PrintWriter(s.getOutputStream(),true);
p.println(str1);
jtf.setText("");
}
catch(Exception e){}
}
else if(ae.getActionCommand().equals("EXIT"))
{
 
System.exit(0);
}
else{}
}
public static void main(String args[])throws IOException{
tcpserver t=new tcpserver();
t.setSize(500,500);
t.setVisible(true);
t.setTitle("SERVER");
t.setDefaultCloseOperation(EXIT_ON_CLOSE);
s1=new ServerSocket(888);
ms.setText("Connection ready...");
s=s1.accept();

while(true)
{
BufferedReader b1=new BufferedReader(new InputStreamReader(s.getInputStream()));

String str=b1.readLine();
ms.setText(ms.getText()+"\nClient: "+str);
}
}
}