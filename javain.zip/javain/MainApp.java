package javaInternal;

import math.Statistics;
import math.convert.BinaryConverter;
import math.convert.OctalConverter;
import math.convert.HexConverter;

public class MainApp {
    public static void main(String[] args) {
        double[] data = {10, 20, 30, 40, 50};

        System.out.println("Mean: " + Statistics.mean(data));
        System.out.println("Median: " + Statistics.median(data));
        System.out.println("Standard Deviation: " + Statistics.standardDeviation(data));

        int decimal = 100;
        System.out.println("Binary of 100: " + BinaryConverter.toBinary(decimal));
        System.out.println("Octal of 100: " + OctalConverter.toOctal(decimal));
        System.out.println("Hex of 100: " + HexConverter.toHex(decimal));

        System.out.println("From Binary '1100100': " + BinaryConverter.fromBinary("1100100"));
        System.out.println("From Octal '144': " + OctalConverter.fromOctal("144"));
        System.out.println("From Hex '64': " + HexConverter.fromHex("64"));
    }
}
