import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.net.InetAddress;
class tcpclient extends JFrame implements ActionListener{
JButton sd,et;
static JTextArea ms;
static JTextField jtf;
JScrollPane sb;
static Container c;
static Socket s;
public tcpclient()
{
 jtf=new JTextField(15);
sd=new JButton("SEND");
et=new JButton("EXIT");
ms=new JTextArea();
sb=new JScrollPane(ms);
sb.setPreferredSize(new Dimension(300,100));
ms.setLineWrap(true);

ms.setWrapStyleWord(true);
ms.setEditable(false);
sb.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
c=getContentPane();
c.setLayout(new FlowLayout());
c.add(jtf);
c.add(sb);
c.add(sd);
c.add(et);
jtf.requestFocus();
ms.setText("Connected to Server port 888.");
sd.addActionListener(this);
et.addActionListener(this);
}

public void actionPerformed(ActionEvent ae)
{
if(ae.getActionCommand().equals("SEND"))
{
try{
String str1=jtf.getText();
ms.setText(ms.getText()+"\nMe: "+str1);
PrintWriter p=new PrintWriter(s.getOutputStream(),true);
p.println(str1);	
jtf.setText("");
}
catch(Exception e){}
}

else if(ae.getActionCommand().equals("EXIT"))
{
 
System.exit(0);
}
else{}
}
public static void main(String args[])throws IOException{
tcpclient t=new tcpclient();
t.setSize(500,500);
t.setVisible(true);
t.setTitle("CLIENT");
t.setDefaultCloseOperation(EXIT_ON_CLOSE);
//ServerSocket s1=new ServerSocket(888);
s=new Socket("Localhost",888);
PrintWriter p=new PrintWriter(s.getOutputStream(),true);
p.println("Connected new IP at port 888.\n");	

while(true){
BufferedReader b1=new BufferedReader(new InputStreamReader(s.getInputStream()));
String str=b1.readLine();
ms.setText(ms.getText()+"\nsErvER: "+str);
}
}
}