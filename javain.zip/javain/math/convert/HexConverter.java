package math.convert;

public class HexConverter {

    public static String toHex(int decimal) {
        return Integer.toHexString(decimal).toUpperCase();
    }

    public static int fromHex(String hex) {
        return Integer.parseInt(hex, 16);
    }
}
