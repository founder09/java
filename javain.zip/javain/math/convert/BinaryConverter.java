package math.convert;

public class BinaryConverter {

    public static String toBinary(int decimal) {
        return Integer.toBinaryString(decimal);
    }

    public static int fromBinary(String binary) {
        return Integer.parseInt(binary, 2);
    }
}
