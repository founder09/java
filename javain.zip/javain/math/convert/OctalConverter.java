package math.convert;

public class OctalConverter {

    public static String toOctal(int decimal) {
        return Integer.toOctalString(decimal);
    }

    public static int fromOctal(String octal) {
        return Integer.parseInt(octal, 8);
    }
}
