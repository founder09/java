package math;

import java.util.Arrays;

public class Statistics {

    public static double mean(double[] data) {
        double sum = 0;
        for (double num : data) {
            sum += num;
        }
        return sum / data.length;
    }

    public static double median(double[] data) {
        Arrays.sort(data);
        int n = data.length;
        if (n % 2 == 0) {
            return (data[n / 2 - 1] + data[n / 2]) / 2;
        } else {
            return data[n / 2];
        }
    }

    public static double standardDeviation(double[] data) {
        double mean = mean(data);
        double sumSq = 0;
        for (double num : data) {
            sumSq += Math.pow(num - mean, 2);
        }
        return Math.sqrt(sumSq / data.length);
    }
}
